package tp_jdr.Personnage;

public abstract class Ennemi extends Personnage {

}
