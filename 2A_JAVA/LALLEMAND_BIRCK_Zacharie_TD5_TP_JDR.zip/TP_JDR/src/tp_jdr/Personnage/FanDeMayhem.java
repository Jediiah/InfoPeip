package tp_jdr.Personnage;

public class FanDeMayhem extends Ennemi {
    
    public FanDeMayhem() {
        this.VieMax = 15;
	    this.VieActuel = 15;
	    this.Degats = 10;
	    this.Hydratation = 75;
	    this.TauxAlcool = 0.0;
	    this.Esquive = 15;
	    this.LieuPrefere = "Temple";
	    this.LieuActuel = "Entrée du Festival";
	    this.Meteo = "Normale";
	    this.NomClasse = "FanDeMayhem";
    }
}
