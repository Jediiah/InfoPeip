package tp_jdr.Personnage;

public class TestPersonnage {

	public static void main(String[] args) {

	}

}