package tp_jdr.Personnage;

public abstract class PersonnageJoueur extends Personnage {

}
