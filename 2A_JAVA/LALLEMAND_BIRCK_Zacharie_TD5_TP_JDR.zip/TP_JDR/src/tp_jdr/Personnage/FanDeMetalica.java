package tp_jdr.Personnage;

public class FanDeMetalica extends Ennemi {
    
    public FanDeMetalica() {
        this.VieMax = 5;
	    this.VieActuel = 5;
	    this.Degats = 5;
	    this.Hydratation = 75;
	    this.TauxAlcool = 0.0;
	    this.Esquive = 5;
	    this.LieuPrefere = "Mainstage";
	    this.LieuActuel = "Entrée du Festival";
	    this.Meteo = "Normale";
	    this.NomClasse = "FanDeMetalica";
    }
}
