package tp_jdr.Personnage;

public class FanDeNightwish extends Ennemi {
    
    public FanDeNightwish() {
        this.VieMax = 10;
	    this.VieActuel = 10;
	    this.Degats = 15;
	    this.Hydratation = 75;
	    this.TauxAlcool = 0.0;
	    this.Esquive = 10;
	    this.LieuPrefere = "Valley";
	    this.LieuActuel = "Entrée du Festival";
	    this.Meteo = "Normale";
	    this.NomClasse = "FanDeNightwish";
    }
}
