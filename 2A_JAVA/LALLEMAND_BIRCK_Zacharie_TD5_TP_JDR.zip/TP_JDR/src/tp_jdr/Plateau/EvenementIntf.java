package tp_jdr.Plateau;

import tp_jdr.Personnage.PersonnageJoueur;

public interface EvenementIntf {
	
	public void Resultat(PersonnageJoueur PJ);

	public String getContenu();
}
